# Inflation and Health

**Exploring whether high inflation countries also see lower life expectancy**  
By Akshyata Bhooshan

This repository builds a publish-ready PDF data story in a Google Docs style using **Python** and **World Bank** data.

It fetches:
- Inflation, consumer prices (annual percent) — FP.CPI.TOTL.ZG
- Life expectancy at birth, total (years) — SP.DYN.LE00.IN

It then computes:
- Average inflation for 2020 to 2023
- Change in life expectancy between 2019 and 2023

Finally, it creates:
- A **bar graph**: top ten high inflation countries vs life expectancy in 2023  
- A **line graph**: change in life expectancy from 2019 to 2023 for selected countries  
- A **PDF** with title, subtitle, byline, narrative, charts, and optional infographics

> Sources inside the PDF are listed simply as **World Bank**, per the assignment requirement.

## Quick start

```bash
# 1) Create a virtual environment (optional)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install libraries
pip install -r requirements.txt

# 3) Build the report (outputs go to ./docs)
python src/build_report.py --outdir docs --title "Inflation and Health"   --subtitle "Exploring whether high inflation countries also see lower life expectancy"   --byline "Akshyata Bhooshan"
```

### Optional: include infographics
Place JPG or PNG images in `assets/` and pass them via flags:

```bash
python src/build_report.py --outdir docs   --cover assets/cover_infographic.jpg   --image assets/supporting_infographic.jpg
```

## Reproducibility notes

- The script pulls data via **wbgapi**, which reads directly from the World Bank API at run time.  
- If you prefer to run offline, download CSVs from the World Bank indicator pages and use `--inflation_csv` and `--lifeexp_csv` to point the script at local files.

## Folder layout

```
.
├── assets/      # put optional infographics here (jpg/png)
├── docs/        # output PDF and charts are saved here
├── src/
│   └── build_report.py
├── README.md
└── requirements.txt
```
