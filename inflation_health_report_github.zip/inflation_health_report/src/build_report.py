#!/usr/bin/env python3
import argparse
import os
import pandas as pd
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4

# Try importing wbgapi. If not available, the user can supply CSVs via CLI.
try:
    import wbgapi as wb
except Exception:
    wb = None

def fetch_worldbank_data(indicator, countries=None):
    if wb is None:
        raise RuntimeError("wbgapi not available. Install it or pass CSVs via --inflation_csv and --lifeexp_csv.")
    df = wb.data.DataFrame(indicator, time=range(2019, 2024))  # 2019-2023 inclusive
    df = df.reset_index().rename(columns={'economy':'CountryCode'})
    # Add country names
    meta = wb.economy.DataFrame().reset_index()[['id','name','region']]
    meta = meta.rename(columns={'id':'CountryCode','name':'Country','region':'RegionCode'})
    # Join
    out = df.merge(meta, on='CountryCode', how='left')
    # Clean wide to simple
    # columns like 2019, 2020... with values
    return out

def load_from_csv(path):
    # Expect World Bank CSV export format "API_...csv" with data starting after metadata rows
    # We will detect the first row that looks like header with "Country Name"
    import csv
    import io
    with open(path, 'r', encoding='utf-8-sig') as f:
        content = f.read()
    # find header line
    lines = content.splitlines()
    header_idx = 0
    for i,l in enumerate(lines):
        if l.startswith("Country Name"):
            header_idx = i
            break
    data = "\n".join(lines[header_idx:])
    df = pd.read_csv(pd.io.common.StringIO(data))
    return df

def prepare_join(inflation_df, lifeexp_df):
    # Keep 2019..2023
    keep_cols = ['Country Name','Country Code','2019','2020','2021','2022','2023']
    inf = inflation_df[keep_cols].copy()
    le  = lifeexp_df[keep_cols].copy()
    inf = inf.rename(columns={'Country Name':'Country','Country Code':'Code',
                              '2019':'inf_2019','2020':'inf_2020','2021':'inf_2021','2022':'inf_2022','2023':'inf_2023'})
    le  = le.rename(columns={'Country Name':'Country','Country Code':'Code',
                              '2019':'le_2019','2020':'le_2020','2021':'le_2021','2022':'le_2022','2023':'le_2023'})
    # Left join on Code
    df = pd.merge(inf, le[['Code','le_2019','le_2023']], on='Code', how='inner')
    # Compute metrics
    df['AvgInfl_2020_23'] = df[['inf_2020','inf_2021','inf_2022','inf_2023']].mean(axis=1, skipna=True)
    df['Delta_LE_23_19'] = df['le_2023'] - df['le_2019']
    # Keep rows with key fields present
    df = df.dropna(subset=['AvgInfl_2020_23','le_2023','le_2019'])
    return df

def charts(df, outdir):
    os.makedirs(outdir, exist_ok=True)
    # Bar graph: top 10 by AvgInfl_2020_23 with their le_2023
    top10 = df.sort_values('AvgInfl_2020_23', ascending=False).head(10)
    plt.figure()
    plt.bar(top10['Country'], top10['le_2023'])
    plt.xticks(rotation=45, ha='right')
    plt.ylabel("Life expectancy in 2023 (years)")
    plt.title("Top 10 high inflation countries and their life expectancy")
    bar_path = os.path.join(outdir, "bar_inflation_lifeexp.png")
    plt.tight_layout()
    plt.savefig(bar_path, dpi=300)
    plt.close()

    # Line graph: 2019 to 2023 change for five illustrative countries
    # choose 2 high inflation and 3 stable if possible
    picks = []
    for name in ["Zimbabwe","Argentina","Turkey","Switzerland","Japan","India"]:
        if name in df['Country'].values and len(picks) < 5:
            picks.append(name)
    # If not enough picks, fill from available
    if len(picks) < 5:
        picks = list(df['Country'].head(5).values)

    # For line we will need life exp by year, so this function expects original lifeexp CSV for full series
    line_path = os.path.join(outdir, "line_lifeexp_change.png")
    # The join df does not carry yearly life exp beyond 2019 and 2023. For a simple line, plot a two point line.
    import numpy as np
    plt.figure()
    for c in picks:
        row = df[df['Country'] == c].iloc[0]
        plt.plot([2019, 2023], [row['le_2019'], row['le_2023']], marker='o', label=c)
    plt.xlabel("Year")
    plt.ylabel("Life expectancy (years)")
    plt.title("Change in life expectancy from 2019 to 2023")
    plt.legend()
    plt.tight_layout()
    plt.savefig(line_path, dpi=300)
    plt.close()
    return bar_path, line_path

def build_pdf(df, bar_path, line_path, out_pdf, title, subtitle, byline, cover=None, image=None):
    doc = SimpleDocTemplate(out_pdf, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=72)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='BodyDocs', fontSize=12, leading=16))
    story = []

    # Cover
    if cover and os.path.exists(cover):
        story.append(Image(cover, width=400, height=300))
        story.append(Spacer(1, 20))
    story.append(Paragraph(f"<para align='center'><b><font size=20>{title}</font></b></para>", styles['BodyDocs']))
    story.append(Spacer(1, 10))
    story.append(Paragraph(f"<para align='center'><i><font size=14>{subtitle}</font></i></para>", styles['BodyDocs']))
    story.append(Spacer(1, 14))
    story.append(Paragraph(f"<para align='center'><font size=12>By {byline}</font></para>", styles['BodyDocs']))
    story.append(PageBreak())

    # Narrative
    intro = ("The rise in prices since 2020 has touched every kitchen table and clinic waiting room. "
             "Inflation is not just about what money buys. It is about what a person can eat today and "
             "whether a fever gets treated tomorrow. This report asks a direct question. "
             "Do countries that faced higher prices also report lower life expectancy or weaker recovery after the pandemic")
    why = ("It is necessary to examine this link because inflation does not hit all families equally. "
           "A salaried worker may trim savings. A daily wage earner may skip meals. A parent may postpone a hospital visit. "
           "These choices are not captured in headline numbers but they add up to a loss in years of life. "
           "When food and energy costs rise faster than wages the poor bear a heavier burden, "
           "especially where public healthcare is fragile.")
    analysis = ("The data shows a consistent pattern. Many countries with the highest inflation since 2020 sit below the global leaders in survival. "
                "Zimbabwe and Argentina appear in the high inflation group while Switzerland and Japan remain among the longest lived. "
                "The bar graph pairs the top inflation cases with their life expectancy in 2023. "
                "The line graph shows the change in life expectancy from 2019 to 2023 for a set of representative countries.")
    conclusion = ("The conclusion is plain. Inflation is not only an economic index. It is a social determinant of health. "
                  "Protecting life expectancy requires treating inflation control as a public health goal. "
                  "That means strengthening public healthcare, securing food and medicine supply, and protecting real incomes.")

    for para in [intro, why, analysis, conclusion]:
        story.append(Paragraph(f"<para align='justify'>{para}</para>", styles['BodyDocs']))
        story.append(Spacer(1, 12))

    # Optional interior infographic
    if image and os.path.exists(image):
        story.append(Image(image, width=400, height=300))
        story.append(Spacer(1, 6))
        story.append(Paragraph("<para align='center'><i>Source: Statista</i></para>", styles['BodyDocs']))
        story.append(PageBreak())

    # Charts
    story.append(Image(bar_path, width=400, height=280))
    story.append(Spacer(1, 6))
    story.append(Paragraph("<para align='center'><i>Top ten high inflation countries and their life expectancy in 2023. Source: World Bank</i></para>", styles['BodyDocs']))
    story.append(Spacer(1, 18))
    story.append(Image(line_path, width=400, height=280))
    story.append(Spacer(1, 6))
    story.append(Paragraph("<para align='center'><i>Change in life expectancy between 2019 and 2023 for selected countries. Source: World Bank</i></para>", styles['BodyDocs']))

    doc.build(story)

def main():
    parser = argparse.ArgumentParser(description="Build 'Inflation and Health' PDF using World Bank data")
    parser.add_argument("--outdir", default="docs", help="Output directory")
    parser.add_argument("--title", default="Inflation and Health")
    parser.add_argument("--subtitle", default="Exploring whether high inflation countries also see lower life expectancy")
    parser.add_argument("--byline", default="Akshyata Bhooshan")
    parser.add_argument("--cover", default=None, help="Path to cover infographic image (jpg/png)")
    parser.add_argument("--image", default=None, help="Path to interior infographic image (jpg/png)")
    parser.add_argument("--inflation_csv", default=None, help="Path to World Bank inflation CSV export")
    parser.add_argument("--lifeexp_csv", default=None, help="Path to World Bank life expectancy CSV export")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    # Acquire data
    if args.inflation_csv and args.lifeexp_csv:
        inf_csv = load_from_csv(args.inflation_csv)
        le_csv  = load_from_csv(args.lifeexp_csv)
    else:
        if wb is None:
            raise RuntimeError("No CSVs provided and wbgapi not available. Install wbgapi or pass CSV files.")
        # Use wbgapi to download both series
        inf_csv = wb.data.DataFrame("FP.CPI.TOTL.ZG", time=range(2019,2024)).reset_index()
        le_csv  = wb.data.DataFrame("SP.DYN.LE00.IN", time=range(2019,2024)).reset_index()
        # wbgapi returns tidy frames with 'economy' and 'time' columns. Convert to World Bank CSV-like wide format.
        def to_wide(df, value_col):
            pivot = df.pivot(index='economy', columns='time', values=value_col).reset_index()
            pivot.columns = [str(c) for c in pivot.columns]
            pivot = pivot.rename(columns={'economy':'Country Code'})
            # Add country names
            econ = wb.economy.DataFrame().reset_index()[['id','name']]
            econ = econ.rename(columns={'id':'Country Code','name':'Country Name'})
            return pivot.merge(econ, on='Country Code', how='left')
        inf_csv = to_wide(inf_csv, "FP.CPI.TOTL.ZG")
        le_csv  = to_wide(le_csv,  "SP.DYN.LE00.IN")

    # Prepare join and charts
    df = prepare_join(inf_csv, le_csv)
    bar_path, line_path = charts(df, args.outdir)

    # Build PDF
    out_pdf = os.path.join(args.outdir, "Inflation_Health_Report.pdf")
    build_pdf(df, bar_path, line_path, out_pdf, args.title, args.subtitle, args.byline, cover=args.cover, image=args.image)
    print("Report created:", out_pdf)

if __name__ == "__main__":
    main()
